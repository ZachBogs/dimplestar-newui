<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dimple Star Transport</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="slide/js/jquery.js"></script>
  <script src="slide/js/amazingslider.js"></script>
  <script src="slide/js/initslider-1.js"></script>
  <link rel="icon" href="images/icon.ico" type="image/x-icon">
</head>
<body class="bg-gray-50 text-gray-800 flex flex-col min-h-screen">

<!-- Navbar -->
<header class="sticky top-0 bg-gray-50 shadow z-50">
  <div class="max-w-7xl mx-auto flex items-center justify-between px-6 py-3">

    <!-- Logo + Brand Name -->
    <a href="index.php" class="flex items-center space-x-2">
      <img src="images/logo.png" alt="Dimple Star Transport" class="h-8 w-8 rounded-full border border-yellow-500">
      <span class="font-bold text-lg text-gray-900">Dimple Star</span>
    </a>

    <!-- Nav Links -->
    <nav>
      <ul class="flex items-center space-x-6 font-medium">
        <?php 
          $current_page = basename($_SERVER['PHP_SELF']); 
        ?>
        <li>
          <a href="index.php" class="<?php echo $current_page=='index.php' ? 'text-blue-600' : 'hover:text-blue-600'; ?>">Home</a>
        </li>
        <li>
          <a href="about.php" class="<?php echo $current_page=='about.php' ? 'text-blue-600' : 'hover:text-blue-600'; ?>">About Us</a>
        </li>
        <li>
          <a href="terminal.php" class="<?php echo $current_page=='terminal.php' ? 'text-blue-600' : 'hover:text-blue-600'; ?>">Terminals</a>
        </li>
        <li>
          <a href="routeschedule.php" class="<?php echo $current_page=='routeschedule.php' ? 'text-blue-600' : 'hover:text-blue-600'; ?>">Routes / Schedules</a>
        </li>
        <li>
          <a href="contact.php" class="<?php echo $current_page=='contact.php' ? 'text-blue-600' : 'hover:text-blue-600'; ?>">Contact</a>
        </li>
        <li>
          <a href="book.php" 
             class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition">
            Book Now
          </a>
        </li>
      </ul>
    </nav>

  </div>
</header>


<!-- Hero Section with Slider & Text Side by Side -->
<section class="max-w-7xl mx-auto mt-8 px-4 grid md:grid-cols-2 gap-8 items-start">
  
  <!-- Slider -->
  <div class="shadow-lg rounded-xl overflow-hidden bg-gray-100 flex items-center justify-center">
    <div id="amazingslider-1" class="w-full flex items-center justify-center">
      <ul class="amazingslider-slides" style="display:none;">
        <li><img src="slide/images/b1.png" class="w-full max-h-[420px] object-contain mx-auto" /></li>
        <li><img src="slide/images/b2.png" class="w-full max-h-[420px] object-contain mx-auto" /></li>
        <li><img src="slide/images/b3.png" class="w-full max-h-[420px] object-contain mx-auto" /></li>
        <li><img src="slide/images/b4.png" class="w-full max-h-[420px] object-contain mx-auto" /></li>
      </ul>
    </div>
  </div>

  <!-- Hero Text & Login Button -->
  <div class="flex flex-col justify-center space-y-5">
    <h1 class="text-3xl md:text-5xl font-extrabold text-gray-800 leading-tight">
      Travel Safely with <span class="text-blue-600">Dimple Star</span>
    </h1>
    <p class="text-gray-600 text-lg md:text-xl">
      Your trusted travel partner across Luzon, ensuring comfort and safety on every trip.
    </p>

    <div>
      <?php
        session_start();
        if(isset($_SESSION['email'])){
          $email = $_SESSION['email'];
          echo "<span class='mr-4 font-medium text-gray-700'>Welcome, $email!</span>";
          echo "<a href='logout.php' class='bg-red-600 text-white px-6 py-3 rounded-2xl shadow hover:bg-red-700 transition'>Logout</a>";
        } else {
          echo "<a href='signlog.php' class='bg-blue-600 text-white px-6 py-3 rounded-2xl shadow hover:bg-blue-700 transition'>Sign Up / Login</a>";
        }
      ?>
    </div>
  </div>
</section>


<!-- Passenger Portal -->
<section class="max-w-4xl mx-auto -mt-10 px-4 relative z-20">
  <div class="bg-white shadow-xl rounded-2xl p-6 flex flex-col sm:flex-row justify-between items-center gap-4">
    <div class="text-lg font-semibold text-gray-800">Passenger Portal</div>
    <div class="text-sm sm:text-base text-center sm:text-right">
      <?php
        session_start();
        if(isset($_SESSION['email'])){
          $email = $_SESSION['email'];
          echo "<span class='mr-4 font-medium text-gray-700'>Welcome, $email!</span>";
          echo "<a href='logout.php' class='text-red-600 hover:underline'>Logout</a>";
        }
        if(empty($email)){
          echo "<a href='signlog.php' class='text-blue-600 hover:underline'>Sign Up / Login</a>";
        }
      ?>
    </div>
  </div>
</section>

<!-- Contact Section -->
<section class="max-w-7xl mx-auto mt-16 px-6 grid md:grid-cols-2 gap-10">
  <!-- Contact Info -->
  <div class="bg-white p-8 shadow-lg rounded-2xl">
    <h2 class="text-2xl font-bold mb-4 text-gray-800">Contact Us</h2>
    <p class="mb-2"><strong>Phone:</strong> 0929 209 0712</p>
    <p class="text-gray-700 leading-relaxed">
      Block 1 Lot 10, Southpoint Subd.<br>
      Brgy Banay-Banay, Cabuyao, Laguna
    </p>
  </div>

  <!-- Date & Time -->
  <div class="bg-white p-8 shadow-lg rounded-2xl flex flex-col justify-center items-center text-center">
    <h3 class="text-lg font-semibold mb-2 text-gray-800">Current Date & Time</h3>
    <div class="text-blue-600 font-bold text-xl sm:text-2xl">
      <?php include_once("php_includes/date_time.php"); ?>
    </div>
  </div>
</section>

<!-- Footer -->
<footer class="bg-gray-900 text-gray-400 mt-16">
  <div class="max-w-7xl mx-auto text-center py-10 px-4">
    <a href="index.php">
      <img src="images/footer-logo.jpg" alt="Dimple Star Transport" class="mx-auto h-12 mb-4">
    </a>
    <p class="text-sm sm:text-base">
      &copy; <?php echo date('Y'); ?> Dimple Star Transport. All Rights Reserved.
    </p>
  </div>
</footer>

</body>
</html>
