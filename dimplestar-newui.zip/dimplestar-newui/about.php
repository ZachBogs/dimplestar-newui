<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dimple Star Transport | About Us</title>
  <link rel="icon" href="images/icon.ico" type="image/x-icon">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    /* RESET */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Segoe UI", Arial, sans-serif;
    }

    body {
      background: #f5f7fa;
      color: #333;
      line-height: 1.6;
    }

    a {
      text-decoration: none;
      color: inherit;
    }

    /* HEADER */
    header {
      background: #fff;
      color: #333;
      padding: 15px 40px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 1000;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }

    header .logo img {
      height: 55px;
    }

    nav ul {
      list-style: none;
      display: flex;
      gap: 25px;
    }

    nav ul li a {
      color: #333;
      font-weight: 500;
      transition: 0.3s;
    }

    nav ul li a:hover,
    nav ul li a.active {
      color: #007bff;
    }

    nav ul li:last-child a {
      background: #007bff;
      color: #fff !important;
      padding: 8px 15px;
      border-radius: 6px;
    }

    /* HERO */
    .hero {
      background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url("images/oldbus.jpg") center/cover no-repeat;
      height: 280px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      text-align: center;
    }

    .hero h1 {
      font-size: 3rem;
      font-weight: bold;
    }

    /* CONTENT */
    .container {
      max-width: 1100px;
      margin: 40px auto;
      padding: 20px;
    }

    .about-section {
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }

    .about-section h2 {
      color: #007bff;
      margin-bottom: 15px;
      font-size: 1.8rem;
      border-left: 6px solid #007bff;
      padding-left: 12px;
    }

    .about-section p {
      margin-bottom: 20px;
      font-size: 1rem;
    }

    .mv {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 30px;
      margin-top: 30px;
    }

    .mv div {
      background: #f8f9fa;
      padding: 20px;
      border-radius: 10px;
      text-align: center;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }

    .mv h3 {
      margin-bottom: 10px;
      color: #007bff;
    }

    /* FOOTER */
    footer {
      background: #0d1b2a;
      color: #bbb;
      text-align: center;
      padding: 25px;
      margin-top: 40px;
    }

    footer img {
      height: 40px;
      margin-bottom: 10px;
    }

    footer p {
      font-size: 0.9rem;
    }

    /* RESPONSIVE */
    @media (max-width: 768px) {
      nav ul {
        flex-direction: column;
        gap: 10px;
      }
      .mv {
        grid-template-columns: 1fr;
      }
      .hero h1 {
        font-size: 2rem;
      }
    }
  </style>
</head>
<body>

  <!-- HEADER -->
  <header>
    <div class="logo">
      <a href="index.php"><img src="images/logo.png" alt="Dimple Star Transport"></a>
    </div>
    <nav>
      <ul>
        <?php $current_page = basename($_SERVER['PHP_SELF']); ?>
        <li><a href="index.php" class="<?php echo $current_page=='index.php' ? 'active' : ''; ?>">Home</a></li>
        <li><a href="about.php" class="<?php echo $current_page=='about.php' ? 'active' : ''; ?>">About Us</a></li>
        <li><a href="terminal.php" class="<?php echo $current_page=='terminal.php' ? 'active' : ''; ?>">Terminals</a></li>
        <li><a href="routeschedule.php" class="<?php echo $current_page=='routeschedule.php' ? 'active' : ''; ?>">Routes & Schedules</a></li>
        <li><a href="contact.php" class="<?php echo $current_page=='contact.php' ? 'active' : ''; ?>">Contact</a></li>
        <li><a href="book.php">Book Now</a></li>
      </ul>
    </nav>
  </header>

  <!-- HERO -->
  <section class="hero">
    <h1>About Us</h1>
  </section>

  <!-- CONTENT -->
  <main class="container">
    <section class="about-section">
      <h2>Our Story</h2>
      <p>
        Dimple Star Transport, formerly known as Napat Transit, has been serving passengers since 1993. 
        The company started its journey with dedication to provide safe, reliable, and comfortable rides 
        across Metro Manila and Mindoro Province. In May 2004, Napat Transit officially transformed into 
        Dimple Star Transport, symbolizing growth, modernization, and a stronger commitment to serve the riding public.
      </p>

      <h2>Mission & Vision</h2>
      <div class="mv">
        <div>
          <h3>Mission</h3>
          <p>To provide superior transport service to Metro Manila and Mindoro Province commuters with comfort, safety, and affordability.</p>
        </div>
        <div>
          <h3>Vision</h3>
          <p>To lead the bus transport industry through innovative services, customer-first initiatives, and sustainable travel solutions.</p>
        </div>
      </div>
    </section>
  </main>

  <!-- FOOTER -->
  <footer>
    <a href="index.php"><img src="images/footer-logo.jpg" alt="Dimple Star Transport"></a>
    <p>&copy; 2025 Dimple Star Transport | All Rights Reserved</p>
  </footer>

</body>
</html>
