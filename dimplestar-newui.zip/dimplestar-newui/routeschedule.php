<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dimple Star Transport | Routes & Schedules</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="icon" href="images/icon.ico" type="image/x-icon">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body class="bg-gray-50 text-gray-800 flex flex-col min-h-screen">

  <!-- Header -->
  <header class="sticky top-0 bg-gray-50 shadow z-50">
    <div class="max-w-7xl mx-auto flex items-center justify-between px-6 py-3">

      <!-- Logo + Brand -->
      <a href="index.php" class="flex items-center space-x-2">
        <img src="images/logo.png" alt="Dimple Star Transport" class="h-8 w-8 rounded-full border border-yellow-500">
        <span class="font-bold text-lg text-gray-900">Dimple Star</span>
      </a>

      <!-- Nav -->
      <nav>
        <ul class="flex items-center space-x-6 font-medium">
          <li><a href="index.php" class="hover:text-blue-600">Home</a></li>
          <li><a href="about.php" class="hover:text-blue-600">About Us</a></li>
          <li><a href="terminal.php" class="hover:text-blue-600">Terminals</a></li>
          <li><a href="routeschedule.php" class="text-blue-600">Routes / Schedules</a></li>
          <li><a href="contact.php" class="hover:text-blue-600">Contact</a></li>
          <li>
            <a href="book.php" 
               class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition">
              Book Now
            </a>
          </li>
        </ul>
      </nav>

      <!-- User Area -->
      <div class="text-sm">
        <?php
          if(isset($_SESSION['email'])){
            $email = $_SESSION['email'];
            echo "<span class='mr-2 font-medium text-gray-700'>Welcome, $email</span>";
            echo "<a href='logout.php' class='text-red-600 hover:underline'>Logout</a>";
          } else {
            echo "<a href='signlog.php' class='text-blue-600 hover:underline'>Login</a>";
          }
        ?>
      </div>
    </div>
  </header>

  <!-- Hero -->
  <section class="relative bg-cover bg-center text-white text-center py-28"
           style="background-image: url('images/route.png'); background-color: rgba(31,41,55,0.7); background-blend-mode: multiply;">
    <h1 class="text-4xl font-bold mb-4">Routes & Schedules</h1>
    <p class="text-lg mb-6">Travel with comfort and convenience. All trips are vice versa.</p>
    <a href="terminal.php" class="bg-blue-600 px-6 py-3 rounded-md font-semibold hover:bg-blue-700 transition">View Terminals</a>
  </section>

  <!-- Routes -->
  <section class="max-w-7xl mx-auto my-16 px-6 flex-grow">
    <h2 class="text-2xl font-bold text-center text-blue-700 mb-10">Available Routes</h2>
    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

      <div class="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition">
        <h3 class="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
          <i class="fa-solid fa-bus text-blue-600"></i> Ali Mall Cubao Terminal → San Jose
        </h3>
        <p class="font-semibold text-blue-600 flex items-center gap-2 mb-2">
          <i class="fa-regular fa-clock"></i> Schedules:
        </p>
        <div class="flex flex-wrap gap-2">
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">9:00 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">10:00 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">1:00 pm</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">4:00 pm</span>
        </div>
      </div>

      <div class="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition">
        <h3 class="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
          <i class="fa-solid fa-bus text-blue-600"></i> Alabang Terminal → San Jose
        </h3>
        <p class="font-semibold text-blue-600 flex items-center gap-2 mb-2">
          <i class="fa-regular fa-clock"></i> Schedules:
        </p>
        <div class="flex flex-wrap gap-2">
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">6:00 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">7:00 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">2:00 pm</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">6:00 pm</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">10:00 pm</span>
        </div>
      </div>

      <div class="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition">
        <h3 class="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
          <i class="fa-solid fa-bus text-blue-600"></i> Cabuyao Terminal → San Jose
        </h3>
        <p class="font-semibold text-blue-600 flex items-center gap-2 mb-2">
          <i class="fa-regular fa-clock"></i> Schedules:
        </p>
        <div class="flex flex-wrap gap-2">
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">8:00 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">9:00 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">4:00 pm</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">8:00 pm</span>
        </div>
      </div>

      <div class="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition">
        <h3 class="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
          <i class="fa-solid fa-bus text-blue-600"></i> Espana Terminal → San Jose
        </h3>
        <p class="font-semibold text-blue-600 flex items-center gap-2 mb-2">
          <i class="fa-regular fa-clock"></i> Schedules:
        </p>
        <div class="flex flex-wrap gap-2">
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">4:30 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">5:30 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">12:00 pm</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">4:00 pm</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">8:00 pm</span>
        </div>
      </div>

      <div class="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition">
        <h3 class="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
          <i class="fa-solid fa-bus text-blue-600"></i> San Lazaro Terminal → San Jose
        </h3>
        <p class="font-semibold text-blue-600 flex items-center gap-2 mb-2">
          <i class="fa-regular fa-clock"></i> Schedules:
        </p>
        <div class="flex flex-wrap gap-2">
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">3:00 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">4:30 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">11:00 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">3:00 pm</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">7:00 pm</span>
        </div>
      </div>

      <div class="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition">
        <h3 class="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
          <i class="fa-solid fa-bus text-blue-600"></i> Pasay Terminal → San Jose
        </h3>
        <p class="font-semibold text-blue-600 flex items-center gap-2 mb-2">
          <i class="fa-regular fa-clock"></i> Schedules:
        </p>
        <div class="flex flex-wrap gap-2">
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">5:00 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">6:00 am</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">1:00 pm</span>
          <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm">3:00 pm</span>
        </div>
      </div>

    </div>
  </section>

  <!-- Footer -->
  <footer class="bg-gray-900 text-gray-300 py-6 mt-12">
    <div class="max-w-7xl mx-auto text-center">
      <img src="images/footer-logo.jpg" alt="Dimple Star Transport" class="mx-auto h-12 mb-3">
      <p class="text-sm">&copy; 2025 Dimple Star Transport. All Rights Reserved.</p>
    </div>
  </footer>

</body>
</html>
