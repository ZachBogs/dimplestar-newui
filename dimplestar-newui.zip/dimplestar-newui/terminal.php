<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dimple Star Transport | Terminals</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="icon" href="images/icon.ico" type="image/x-icon">
</head>
<body class="bg-gray-50 text-gray-800">
  <!-- Wrapper -->
  <div class="flex flex-col min-h-screen">
    
    <!-- Header -->
    <header class="sticky top-0 bg-gray-50 shadow z-50">
      <div class="max-w-7xl mx-auto flex items-center justify-between px-6 py-3">
        
        <!-- Logo + Brand -->
        <a href="index.php" class="flex items-center space-x-2">
          <img src="images/logo.png" alt="Dimple Star Transport" class="h-8 w-8 rounded-full border border-yellow-500">
          <span class="font-bold text-lg text-gray-900">Dimple Star</span>
        </a>

        <!-- Nav -->
        <nav>
          <ul class="flex items-center space-x-6 font-medium">
            <li><a href="index.php" class="hover:text-blue-600">Home</a></li>
            <li><a href="about.php" class="hover:text-blue-600">About Us</a></li>
            <li><a href="terminal.php" class="text-blue-600">Terminals</a></li>
            <li><a href="routeschedule.php" class="hover:text-blue-600">Routes / Schedules</a></li>
            <li><a href="contact.php" class="hover:text-blue-600">Contact</a></li>
            <li>
              <a href="book.php" 
                 class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition">
                Book Now
              </a>
            </li>
          </ul>
        </nav>

      </div>
    </header>

    <!-- Content -->
    <main class="flex-grow max-w-7xl mx-auto p-6">
      <h1 class="text-3xl font-bold text-center text-blue-700 mb-8">Our Terminals</h1>

      <!-- Terminal Cards -->
      <section class="grid md:grid-cols-2 gap-8">
        <!-- España Terminal -->
        <div class="bg-white rounded-2xl shadow-md overflow-hidden">
          <div class="p-4">
            <h2 class="text-xl font-bold text-gray-900 mb-2">España Terminal</h2>
            <p class="text-gray-600 mb-2">836B Antipolo St, Sampaloc, Manila</p>
            <p class="font-semibold mb-4">☎ +63 02 985 1451 / +63 908 926 9163</p>
            <iframe width="100%" height="250" frameborder="0" style="border:0" allowfullscreen
              src="https://maps.google.com.ph/maps?f=q&amp;source=s_q&amp;hl=en&amp;q=Dimple+Star,+836BAntipoloStSampaloc,521,Manila&amp;t=h&amp;ie=UTF8&amp;ll=14.6125312,120.9948033&amp;z=14&amp;output=embed">
            </iframe>
          </div>
        </div>

        <!-- San Jose Terminal -->
        <div class="bg-white rounded-2xl shadow-md overflow-hidden">
          <div class="p-4">
            <h2 class="text-xl font-bold text-gray-900 mb-2">San Jose Terminal</h2>
            <p class="text-gray-600 mb-2">Bonifacio St, San Jose, Occidental Mindoro</p>
            <p class="font-semibold mb-4">☎ +63 02 668 4151 / +63 921 568 6449</p>
            <iframe width="100%" height="250" frameborder="0" style="border:0" allowfullscreen
              src="https://maps.google.com.ph/maps?f=q&amp;source=s_q&amp;hl=en&amp;q=Dimple+Star+Transport,+BonifacioSt,SanJose,OccidentalMindoro&amp;t=h&amp;ie=UTF8&amp;ll=12.3540632,121.0618653&amp;z=14&amp;output=embed">
            </iframe>
          </div>
        </div>
      </section>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-900 text-gray-300 py-6 mt-12">
      <div class="max-w-7xl mx-auto text-center">
        <img src="images/footer-logo.jpg" alt="Dimple Star Transport" class="mx-auto h-12 mb-3">
        <p class="text-sm">&copy; 2025 Dimple Star Transport. All rights reserved.</p>
      </div>
    </footer>
  </div>
</body>
</html>
