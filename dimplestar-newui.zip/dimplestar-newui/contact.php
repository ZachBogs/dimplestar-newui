<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dimple Star Transport | Contact</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" href="images/icon.ico" type="image/x-icon">
</head>
<body class="bg-gray-50 text-gray-800 flex flex-col min-h-screen">

  <!-- Header -->
  <header class="sticky top-0 bg-gray-50 shadow z-50">
    <div class="max-w-7xl mx-auto flex items-center justify-between px-6 py-3">
      
      <!-- Logo + Brand -->
      <a href="index.php" class="flex items-center space-x-2">
        <img src="images/logo.png" alt="Dimple Star Transport" class="h-8 w-8 rounded-full border border-yellow-500">
        <span class="font-bold text-lg text-gray-900">Dimple Star</span>
      </a>

      <!-- Nav -->
      <nav>
        <ul class="flex items-center space-x-6 font-medium">
          <li><a href="index.php" class="hover:text-blue-600">Home</a></li>
          <li><a href="about.php" class="hover:text-blue-600">About Us</a></li>
          <li><a href="terminal.php" class="hover:text-blue-600">Terminals</a></li>
          <li><a href="routeschedule.php" class="hover:text-blue-600">Routes / Schedules</a></li>
          <li><a href="contact.php" class="text-blue-600">Contact</a></li>
          <li>
            <a href="book.php" 
               class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition">
              Book Now
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </header>

  <!-- Hero Section -->
  <section class="relative bg-[url('images/bus-bg.jpg')] bg-cover bg-center h-64 flex items-center justify-center text-white">
    <div class="bg-gray-800 bg-opacity-70 p-6 rounded-lg">
      <h1 class="text-3xl font-bold">Contact Dimple Star Transport</h1>
      <p class="text-lg">We’re here to help with your travel needs</p>
    </div>
  </section>

  <!-- Content -->
  <main class="max-w-7xl mx-auto py-12 px-6 grid grid-cols-1 md:grid-cols-2 gap-10 flex-grow">
    <!-- Contact Info -->
    <div class="space-y-6">
      <h2 class="text-2xl font-bold border-b-2 border-blue-600 inline-block pb-1">Get in Touch</h2>
      <p class="text-gray-700 leading-relaxed">
        Have questions about your trip or booking? Reach out to us through the details below or send us a message via our contact form.
      </p>
      <div class="bg-white shadow-md rounded-lg p-6 space-y-3">
        <p><strong>Address:</strong> Block 1 Lot 10, Southpoint Subd., Brgy Banay-Banay, Cabuyao, Laguna</p>
        <p><strong>Phone:</strong> <a href="tel:09292090712" class="text-blue-600 hover:underline">0929 209 0712</a></p>
        <p><strong>Email:</strong> <a href="mailto:info@dimplestar.com" class="text-blue-600 hover:underline">info@dimplestar.com</a></p>
        <p><strong>Business Hours:</strong> 6:00 AM – 10:00 PM (Mon–Sun)</p>
      </div>
    </div>

    <!-- Contact Form -->
    <div class="bg-white shadow-md rounded-lg p-8">
      <h3 class="text-xl font-semibold mb-6">Send Us a Message</h3>
      <form action="messageexec.php" method="POST" class="space-y-5">
        <div>
          <label for="name" class="block font-medium mb-1">Name</label>
          <input type="text" id="name" name="name" class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-600" required>
        </div>
        <div>
          <label for="email" class="block font-medium mb-1">Email</label>
          <input type="email" id="email" name="email" placeholder="you@example.com" class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-600" required>
        </div>
        <div>
          <label for="subject" class="block font-medium mb-1">Subject</label>
          <input type="text" id="subject" name="subject" class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-600" required>
        </div>
        <div>
          <label for="message" class="block font-medium mb-1">Message</label>
          <textarea id="message" name="message" rows="5" class="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-600" required></textarea>
        </div>
        <button type="submit" class="w-full bg-blue-600 text-white font-bold py-2 rounded-lg hover:bg-blue-700 transition">Send Message</button>
      </form>
    </div>
  </main>

  <!-- Footer -->
  <footer class="bg-gray-900 text-gray-300 py-6 mt-12">
    <div class="max-w-7xl mx-auto text-center">
      <img src="images/footer-logo.jpg" alt="Dimple Star Transport" class="mx-auto h-12 mb-3">
      <p class="text-sm">&copy; 2025 Dimple Star Transport. All Rights Reserved.</p>
    </div>
  </footer>

</body>
</html>
