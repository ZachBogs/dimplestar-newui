<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dimple Star Transport - Book Your Trip</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="icon" href="images/icon.ico" type="image/x-icon">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f5f7fa;
      color: #333;
    }

    /* HEADER */
    header {
      background: #fff;
      color: #333;
      padding: 15px 40px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 1000;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }

    header img.logo {
      height: 55px;
    }

    nav ul {
      list-style: none;
      display: flex;
      gap: 25px;
    }

    nav a {
      color: #333;
      text-decoration: none;
      font-weight: 500;
      transition: 0.3s;
    }

    nav a:hover,
    nav a.active {
      color: #007bff;
    }

    nav ul li:last-child a {
      background: #007bff;
      color: #fff !important;
      padding: 8px 15px;
      border-radius: 6px;
    }

    /* HERO */
    .hero {
      background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('images/bus-bg.jpg') center/cover no-repeat;
      height: 280px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      text-align: center;
    }

    .hero h1 {
      font-size: 2.5rem;
      font-weight: bold;
    }

    /* BOOKING FORM */
    .booking-section {
      max-width: 900px;
      margin: -50px auto 50px auto;
      background: #fff;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    .booking-section h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #007bff;
    }

    form {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
    }

    label {
      font-weight: 600;
      margin-bottom: 5px;
      display: block;
    }

    select, input[type="number"], input[type="text"], input[type="date"] {
      width: 100%;
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 1rem;
    }

    .trip-type {
      display: flex;
      gap: 15px;
      align-items: center;
    }

    .btn-submit {
      grid-column: span 2;
      background: #007bff;
      color: #fff;
      padding: 12px;
      font-size: 1.1rem;
      font-weight: bold;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .btn-submit:hover {
      background: #0056b3;
    }

    /* FOOTER */
    footer {
      text-align: center;
      padding: 25px;
      background: #0d1b2a;
      color: #bbb;
      font-size: 0.9rem;
    }

    footer img {
      height: 40px;
      display: block;
      margin: 0 auto 10px;
    }

    /* RESPONSIVE */
    @media (max-width: 768px) {
      nav ul {
        flex-direction: column;
        gap: 10px;
      }
      .hero h1 {
        font-size: 2rem;
      }
      form {
        grid-template-columns: 1fr;
      }
      .btn-submit {
        grid-column: 1;
      }
    }
  </style>
</head>
<body>

<header>
  <a href="index.php"><img src="images/logo.png" class="logo" alt="Dimple Star Transport"></a>
  <nav>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="terminal.php">Terminals</a></li>
      <li><a href="routeschedule.php">Routes & Schedules</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="book.php" class="active">Book Now</a></li>
    </ul>
  </nav>
</header>

<section class="hero">
  <h1>Your Journey Starts with Dimple Star</h1>
</section>

<section class="booking-section">
  <h2>Book Your Trip</h2>
  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
    
    <div class="trip-type">
      <label><input type="radio" name="way" value="1" checked> One Way</label>
      <label><input type="radio" name="way" value="2"> Round Trip</label>
    </div>

    <div>
      <label for="origin">Origin</label>
      <select name="Origin" id="origin" required>
        <option value="">Select</option>
        <option>San Lazaro</option>
        <option>Espana</option>
        <option>Alabang</option>
        <option>Cabuyao</option>
        <option>Naujan</option>
        <option>Victoria</option>
        <option>Pinamalayan</option>
        <option>Gloria</option>
        <option>Bongabong</option>
        <option>Roxas</option>
        <option>Mansalay</option>
        <option>Bulalacao</option>
        <option>Magsaysay</option>
        <option>San Jose</option>
        <option>Pola</option>
        <option>Soccoro</option>
      </select>
    </div>

    <div>
      <label for="destination">Destination</label>
      <select name="Destination" id="destination" required>
        <option value="">Select</option>
        <option>San Lazaro</option>
        <option>Espana</option>
        <option>Alabang</option>
        <option>Cabuyao</option>
        <option>Naujan</option>
        <option>Victoria</option>
        <option>Pinamalayan</option>
        <option>Gloria</option>
        <option>Bongabong</option>
        <option>Roxas</option>
        <option>Mansalay</option>
        <option>Bulalacao</option>
        <option>Magsaysay</option>
        <option>San Jose</option>
        <option>Pola</option>
        <option>Soccoro</option>
      </select>
    </div>

    <div>
      <label for="passengers">No. of Passengers</label>
      <input type="number" name="no_of_pass" id="passengers" min="1" required>
    </div>

    <div>
      <label for="departure">Departure Date</label>
      <input type="date" name="Departure" id="departure" required>
    </div>

    <div>
      <label for="return">Return Date</label>
      <input type="date" name="Return" id="return">
    </div>

    <div>
      <label for="bustype">Bus Type</label>
      <select name="bustype" id="bustype" required>
        <option value="">Select</option>
        <option>Air Conditioned</option>
        <option>Ordinary</option>
      </select>
    </div>

    <button type="submit" name="submit" class="btn-submit">Find Buses</button>
  </form>
</section>

<footer>
  <img src="images/footer-logo.jpg" alt="Dimple Star Transport">
  <p>&copy; <?php echo date("Y"); ?> Dimple Star Transport. All Rights Reserved.</p>
</footer>

</body>
</html>
